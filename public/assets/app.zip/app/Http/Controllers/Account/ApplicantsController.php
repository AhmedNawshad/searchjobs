<?php

namespace App\Http\Controllers\Account;

use App\Models\User;
use App\Helpers\UrlGen;
use App\Models\Message;
use App\Models\Applicants;
use App\Notifications\ReplySent;
use App\Http\Requests\ReplyMessageRequest;
use Torann\LaravelMetaTags\Facades\MetaTag;

class ApplicantsController extends AccountBaseController
{

    public function index()
    {


        $applicants = Applicants::all();


        return view('account.applicants', ['applicants' => $applicants]);
    }
}