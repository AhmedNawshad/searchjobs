<?php

namespace App\Http\Controllers\Account;

use App\Models\User;
use App\Helpers\UrlGen;
use App\Models\Message;
use App\Models\Meetings;
use App\Models\Applicants;
use App\Notifications\ReplySent;
use Illuminate\Support\Facades\Auth;
use App\Http\Requests\ReplyMessageRequest;
use Torann\LaravelMetaTags\Facades\MetaTag;

class MeetingController extends AccountBaseController
{

    public function index()
    {

        $mettings = Meetings::all();


        return view('account.meetings', ['meetings' => $mettings]);
    }
}