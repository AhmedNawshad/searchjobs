<input type="password" id="{{ $name }}" value="{{ isset($value) ? $value : "" }}" autocomplete="new-password" type="text" name="{{ $name }}" class="form-control{{ $classes }}">
