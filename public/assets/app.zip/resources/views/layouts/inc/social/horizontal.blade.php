<div class="text-center mt-4 mb-4 ml-0 mr-0">
	<button class='btn btn-fb share s_facebook'><i class="icon-facebook"></i> </button>&nbsp;
	<button class='btn btn-tw share s_twitter'><i class="icon-twitter"></i> </button>&nbsp;
	<button class='btn btn-danger share s_plus'><i class="icon-googleplus-rect"></i> </button>&nbsp;
	<button class='btn btn-lin share s_linkedin'><i class="icon-linkedin"></i> </button>
</div>